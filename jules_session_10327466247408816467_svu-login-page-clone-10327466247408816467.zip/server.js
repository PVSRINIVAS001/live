const express = require('express');
const path = require('path');

const app = express();
const port = 3000;

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Mock data
const results = {
    '1AB123': {
        name: 'John Doe',
        usn: '1AB123',
        marks: [
            { subject: 'Subject 1', score: 85 },
            { subject: 'Subject 2', score: 90 },
            { subject: 'Subject 3', score: 78 },
        ],
    },
    '1AB456': {
        name: 'Jane Smith',
        usn: '1AB456',
        marks: [
            { subject: 'Subject 1', score: 92 },
            { subject: 'Subject 2', score: 88 },
            { subject: 'Subject 3', score: 95 },
        ],
    },
};

// API endpoint to get results
app.get('/api/result', (req, res) => {
    const { usn } = req.query;
    if (results[usn]) {
        res.json(results[usn]);
    } else {
        res.status(404).json({ error: 'Result not found' });
    }
});

// Serve index.html for the root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
