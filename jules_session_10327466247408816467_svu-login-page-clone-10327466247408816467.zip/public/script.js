document.getElementById('result-form').addEventListener('submit', async function(event) {
    event.preventDefault();

    const usn = document.getElementById('usn').value;
    const resultContainer = document.getElementById('result-container');
    const studentName = document.getElementById('student-name');
    const studentUsn = document.getElementById('student-usn');
    const marksTable = document.getElementById('marks-table');

    try {
        const response = await fetch(`/api/result?usn=${usn}`);
        if (!response.ok) {
            throw new Error('Result not found');
        }
        const data = await response.json();

        studentName.textContent = data.name;
        studentUsn.textContent = data.usn;
        marksTable.innerHTML = '';

        data.marks.forEach(mark => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${mark.subject}</td>
                <td>${mark.score}</td>
            `;
            marksTable.appendChild(row);
        });

        resultContainer.style.display = 'block';
    } catch (error) {
        alert(error.message);
        resultContainer.style.display = 'none';
    }
});
